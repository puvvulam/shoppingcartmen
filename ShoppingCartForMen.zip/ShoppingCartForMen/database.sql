CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(350) NOT NULL,
  `email` varchar(350) NOT NULL,
  `password` varchar(350) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
); 
INSERT INTO `users` VALUES (1,'wood','wood1234@mail.com','Abc@12345');

CREATE TABLE `products` (
  `id` int NOT NULL,
  `name` varchar(550) NOT NULL,
  `price` double NOT NULL,
  `image` varchar(550) NOT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `products` VALUES (1,'Latest Collection Mens Tshirts',100,'tshirts.jpg'),(2,'Stylish and Formal Men Shirts',80.50,'shirts.jpg'),(3,'Interview dress',150,'interview-dress.jpg'),(4,'Shorts',90,'shorts.jpg'),(5,'Track pants',75,'tracks-pants.jpg'),(6,'Men pants',120,'pants.jpg');

CREATE TABLE `orders` (
  `o_id` int NOT NULL AUTO_INCREMENT,
  `p_id` int NOT NULL,
  `u_id` int NOT NULL,
  `o_quantity` int NOT NULL,
  PRIMARY KEY (`o_id`)
); 

INSERT INTO `orders` VALUES (14,3,1,3),(15,2,1,1);

DROP TABLE IF EXISTS `products`;




